package com.baeldung.lsd.persistence.model;

import javax.persistence.*;

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, updatable = false)
    private String email;
    private String firstName;
    private String lastName;

    public User() {}
}