package com.baeldung.lsd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersistenceProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersistenceProjectApplication.class, args);
	}

}
