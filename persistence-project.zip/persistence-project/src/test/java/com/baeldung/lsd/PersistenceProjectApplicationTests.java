package com.baeldung.lsd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersistenceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
